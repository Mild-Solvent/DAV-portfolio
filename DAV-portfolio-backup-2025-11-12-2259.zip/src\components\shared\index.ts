export { default as SectionHeading } from './SectionHeading';
export { default as GlowStrip } from './GlowStrip';
