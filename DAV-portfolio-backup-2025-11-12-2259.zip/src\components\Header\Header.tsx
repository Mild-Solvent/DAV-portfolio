import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import Image from 'next/image';
import { useTranslation } from '../../contexts/TranslationContext';
import LanguageSwitch from '../LanguageSwitch/LanguageSwitch';

interface HeaderContainerProps {
  isScrolled: boolean;
}

const HeaderContainer = styled(motion.header)<HeaderContainerProps>`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: ${props => props.theme.zIndex.navbar};
  background: ${props => props.isScrolled ? 'rgba(13, 17, 23, 0.98)' : 'rgba(13, 17, 23, 0.85)'};
  backdrop-filter: blur(16px);
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  padding: ${props => props.theme.spacing.lg} 0;
`;

const Nav = styled.nav`
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 ${props => props.theme.spacing['2xl']};
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
  gap: ${props => props.theme.spacing['2xl']};
  
  @media (max-width: ${props => props.theme.breakpoints.lg}) {
    padding: 0 ${props => props.theme.spacing.xl};
    gap: ${props => props.theme.spacing.xl};
  }
  
  @media (max-width: ${props => props.theme.breakpoints.md}) {
    padding: 0 ${props => props.theme.spacing.lg};
    gap: ${props => props.theme.spacing.lg};
  }
`;

const LeftSection = styled.div`
  display: flex;
  align-items: center;
  flex-shrink: 0;
`;

const RightSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${props => props.theme.spacing.lg};
  flex-shrink: 0;
  
  @media (max-width: ${props => props.theme.breakpoints.lg}) {
    gap: ${props => props.theme.spacing.md};
  }
  
  @media (max-width: ${props => props.theme.breakpoints.md}) {
    position: relative;
    gap: ${props => props.theme.spacing.sm};
  }
`;

const Logo = styled.div`
  display: flex;
  align-items: center;
  gap: ${props => props.theme.spacing.md};
  cursor: pointer;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  padding: ${props => props.theme.spacing.sm};
  border-radius: ${props => props.theme.borderRadius.lg};
  flex-shrink: 0;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 20px rgba(88, 166, 255, 0.2);
  }
`;

const LogoImage = styled(Image)`
  border-radius: ${props => props.theme.borderRadius.md};
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  
  ${Logo}:hover & {
    transform: scale(1.05);
    filter: brightness(1.1);
  }
`;

const LogoText = styled.span`
  font-family: ${props => props.theme.fonts.display};
  font-size: ${props => props.theme.fontSizes.xl};
  font-weight: 700;
  background: ${props => props.theme.gradients.blue};
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  letter-spacing: -0.02em;
  
  @media (max-width: ${props => props.theme.breakpoints.sm}) {
    font-size: ${props => props.theme.fontSizes.lg};
  }
`;

interface NavListProps {
  $isOpen: boolean;
}

const NavList = styled.ul<NavListProps>`
  list-style: none;
  gap: ${props => props.theme.spacing.xl};
  align-items: center;
  margin: 0;
  padding: 0;
  flex-wrap: nowrap;

  /* When mobile menu should be shown, hide the regular nav and show dropdown when open */
  @media (max-width: 1400px) {
    display: ${props => props.$isOpen ? 'flex' : 'none'};
    position: absolute;
    top: calc(100% + ${props => props.theme.spacing.md});
    right: 0;
    background: rgba(22, 27, 34, 0.98);
    backdrop-filter: blur(20px);
    flex-direction: column;
    padding: ${props => props.theme.spacing['2xl']};
    border-radius: ${props => props.theme.borderRadius.xl};
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4);
    gap: ${props => props.theme.spacing.md};
    border: 1px solid rgba(48, 54, 61, 0.5);
    min-width: 200px;
    z-index: 1000;
  }

  /* Desktop: show normal horizontal navigation */
  @media (min-width: 1401px) {
    display: flex;
    position: static;
    background: none;
    backdrop-filter: none;
    flex-direction: row;
    padding: 0;
    border-radius: 0;
    box-shadow: none;
    border: none;
    min-width: auto;
    z-index: auto;
  }
`;

const NavItem = styled.li``;

const NavLink = styled.a`
  color: ${props => props.theme.colors.text};
  font-weight: 500;
  font-size: ${props => props.theme.fontSizes.base};
  position: relative;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  cursor: pointer;
  padding: ${props => props.theme.spacing.md} ${props => props.theme.spacing.lg};
  border-radius: ${props => props.theme.borderRadius.lg};
  text-decoration: none;
  letter-spacing: 0.01em;
  white-space: nowrap;

  &:hover {
    color: ${props => props.theme.colors.textEmphasis};
    background: rgba(88, 166, 255, 0.1);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(88, 166, 255, 0.15);
  }
  
  &::after {
    content: '';
    position: absolute;
    bottom: -2px;
    left: 50%;
    width: 0;
    height: 2px;
    background: ${props => props.theme.gradients.blue};
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    transform: translateX(-50%);
    border-radius: ${props => props.theme.borderRadius.full};
  }
  
  &:hover::after {
    width: 80%;
  }
  
  @media (max-width: ${props => props.theme.breakpoints.lg}) {
    padding: ${props => props.theme.spacing.sm} ${props => props.theme.spacing.md};
    font-size: ${props => props.theme.fontSizes.sm};
  }
  
  @media (max-width: ${props => props.theme.breakpoints.md}) {
    padding: ${props => props.theme.spacing.lg};
    width: 100%;
    text-align: center;
    font-size: ${props => props.theme.fontSizes.base};
    
    &::after {
      display: none;
    }
  }
`;

const MobileMenuButton = styled.button`
  display: none;
  background: none;
  border: 2px solid transparent;
  color: ${props => props.theme.colors.text};
  font-size: ${props => props.theme.fontSizes['2xl']};
  padding: ${props => props.theme.spacing.md};
  border-radius: ${props => props.theme.borderRadius.lg};
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  cursor: pointer;
  flex-shrink: 0;
  
  &:hover {
    background: rgba(88, 166, 255, 0.1);
    border-color: rgba(88, 166, 255, 0.3);
    color: ${props => props.theme.colors.textEmphasis};
    transform: scale(1.05);
  }

  /* Show burger menu when navigation needs to collapse */
  @media (max-width: 1400px) {
    display: flex;
    align-items: center;
    justify-content: center;
  }
`;


interface HeaderWithMobileStateProps {
  isMobileMenuOpen: boolean;
  setIsMobileMenuOpen: (isOpen: boolean) => void;
}

const HeaderWithMobileState: React.FC<HeaderWithMobileStateProps> = ({ 
  isMobileMenuOpen, 
  setIsMobileMenuOpen 
}) => {
  const { t } = useTranslation();
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    const handleResize = () => {
      const width = window.innerWidth;
      
      // Close mobile menu if screen becomes desktop size
      if (width > 1400) {
        setIsMobileMenuOpen(false);
      }
    };

    // Initial check
    handleResize();

    window.addEventListener('scroll', handleScroll);
    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('resize', handleResize);
    };
  }, [setIsMobileMenuOpen]);

  const scrollToSection = (sectionId: string) => {
    // Check if we're on a different page (like calculator)
    const currentPath = window.location.pathname;
    const currentLang = currentPath.split('/')[1] || 'en';
    const isOnHomePage = currentPath === `/${currentLang}` || currentPath === `/${currentLang}/`;
    
    if (!isOnHomePage) {
      // If not on home page, navigate to home with hash
      window.location.href = sectionId === 'hero' 
        ? `/${currentLang}` 
        : `/${currentLang}#${sectionId}`;
      return;
    }
    
    // On home page, scroll to section
    if (sectionId === 'hero') {
      // Scroll to top for hero section
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      const element = document.getElementById(sectionId);
      if (element) {
        // For other sections, account for the hero offset
        const elementTop = element.offsetTop + window.innerHeight;
        window.scrollTo({ top: elementTop, behavior: 'smooth' });
      }
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <HeaderContainer
      isScrolled={isScrolled}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Nav>
        <LeftSection>
          <Logo onClick={() => scrollToSection('hero')}>
            <LogoImage 
              src="/logo/logo.png" 
              alt="Portfolio Logo" 
              width={40} 
              height={40}
              priority
            />
            <LogoText>{t('header.logo')}</LogoText>
          </Logo>
        </LeftSection>
        
        <RightSection>
          <NavList $isOpen={isMobileMenuOpen}>
            <NavItem>
              <NavLink onClick={() => scrollToSection('hero')}>{t('header.home')}</NavLink>
            </NavItem>
            <NavItem>
              <NavLink onClick={() => scrollToSection('about')}>{t('header.about')}</NavLink>
            </NavItem>
            <NavItem>
              <NavLink onClick={() => scrollToSection('projects')}>{t('header.projects')}</NavLink>
            </NavItem>
            <NavItem>
              <NavLink onClick={() => scrollToSection('services')}>{t('header.services')}</NavLink>
            </NavItem>
            <NavItem>
              <NavLink onClick={() => scrollToSection('skills')}>{t('header.skills')}</NavLink>
            </NavItem>
            <NavItem>
              <NavLink onClick={() => scrollToSection('contact')}>{t('header.contact')}</NavLink>
            </NavItem>
          </NavList>

          <MobileMenuButton
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="Toggle mobile menu"
          >
            {isMobileMenuOpen ? '×' : '☰'}
          </MobileMenuButton>
        </RightSection>
      </Nav>
    </HeaderContainer>
  );
};


// Floating Language Switch positioned outside header
interface FloatingLanguageSwitchProps {
  $isMobileMenuOpen: boolean;
}

const FloatingLanguageSwitch = styled(motion.div)<FloatingLanguageSwitchProps>`
  position: fixed;
  top: calc(${props => props.theme.spacing.lg} * 2 + 80px); /* Extra space to avoid header animation */
  right: ${props => props.theme.spacing['2xl']};
  z-index: ${props => props.theme.zIndex.dropdown + 10}; /* Above all dropdowns */
  transition: top 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  
  @media (max-width: ${props => props.theme.breakpoints.lg}) {
    right: ${props => props.theme.spacing.xl};
  }
  
  @media (max-width: ${props => props.theme.breakpoints.md}) {
    right: ${props => props.theme.spacing.lg};
    top: calc(${props => props.theme.spacing.lg} * 2 + 70px); /* Extra space on mobile */
  }
  
  /* When mobile menu is open on smaller screens, move below the dropdown */
  @media (max-width: 1400px) {
    top: ${props => props.$isMobileMenuOpen 
      ? `calc(${props.theme.spacing.lg} * 2 + 80px + 300px)` /* Below mobile menu */
      : `calc(${props.theme.spacing.lg} * 2 + 80px)`}; /* Normal position */
  }
  
  @media (max-width: ${props => props.theme.breakpoints.md}) {
    top: ${props => props.$isMobileMenuOpen 
      ? `calc(${props.theme.spacing.lg} * 2 + 70px + 280px)` /* Below mobile menu on mobile */
      : `calc(${props.theme.spacing.lg} * 2 + 70px)`}; /* Normal position on mobile */
  }
`;

const HeaderWithLanguageSwitch: React.FC = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <>
      <HeaderWithMobileState 
        isMobileMenuOpen={isMobileMenuOpen} 
        setIsMobileMenuOpen={setIsMobileMenuOpen} 
      />
      <FloatingLanguageSwitch 
        $isMobileMenuOpen={isMobileMenuOpen}
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.3 }} // Delay to appear after header animation
      >
        <LanguageSwitch />
      </FloatingLanguageSwitch>
    </>
  );
};

export { HeaderWithMobileState as Header };
export default HeaderWithLanguageSwitch;
